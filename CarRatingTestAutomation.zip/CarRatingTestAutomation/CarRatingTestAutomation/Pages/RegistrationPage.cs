﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace CarRatingTestAutomation.Pages
{
    public class RegistrationPage
    {
        public IWebDriver driver;
        public RegistrationPage(IWebDriver webDriver)
        {
            driver = webDriver;
        }

        IWebElement txtLogin => driver.FindElement(By.Id("username"));
        IWebElement txtFirstName => driver.FindElement(By.Id("firstName"));
        IWebElement txtLastName => driver.FindElement(By.Id("lastName"));
        IWebElement txtPassword => driver.FindElement(By.Id("password"));
        IWebElement txtConfirmPassword => driver.FindElement(By.Id("confirmPassword"));
        IWebElement btnRegister => driver.FindElement(By.XPath("//button[text()='Register']"));
        IWebElement alertMessage => driver.FindElement(By.XPath("//div[contains(@class, 'result alert alert')]"));

        public void Register(string login, string firstname, string lastname, string password, string confirmPassword)
        {
            txtLogin.SendKeys(login);
            txtFirstName.SendKeys(firstname);
            txtLastName.SendKeys(lastname);
            txtPassword.SendKeys(password);
            txtConfirmPassword.SendKeys(confirmPassword);
            btnRegister.Click();
        }

        public void validateMessage(string message)
        {
            Thread.Sleep(1000);
            string textMessage = alertMessage.Text;
            Assert.IsTrue(textMessage.Contains(message), "Alert message is incorrect and displayed: " + textMessage);
        }

    }
}
