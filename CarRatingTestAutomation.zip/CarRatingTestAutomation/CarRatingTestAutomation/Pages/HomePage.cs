﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace CarRatingTestAutomation.Pages
{
    public class HomePage
    {
        public IWebDriver driver;
        public HomePage(IWebDriver webDriver)
        {
            driver = webDriver;
        }
        IWebElement btnLogin => driver.FindElement(By.XPath("//button[@type='submit']"));
        IWebElement btnRegister => driver.FindElement(By.XPath("//a[text()='Register']"));
        IWebElement txtLogin => driver.FindElement(By.Name("login"));
        IWebElement txtPassword => driver.FindElement(By.Name("password"));
        IWebElement profileName => driver.FindElement(By.XPath("//span[@class='nav-link disabled']"));

        public void ClickOnRegister()
        {
            btnRegister.Click();
        }

        public void Login(string login, string password)
        {
            Console.WriteLine("login: " + login);
            txtLogin.SendKeys(login);
            txtPassword.SendKeys(password);
            btnLogin.Click();
        }

        public void validateProfileName(string firstname)
        {
            Thread.Sleep(1000);
            string txtProfileName = profileName.Text;
            Assert.IsTrue(txtProfileName.Contains(firstname), "Profile Name is incorrect and displayed: " + txtProfileName);
        }
    }
}
