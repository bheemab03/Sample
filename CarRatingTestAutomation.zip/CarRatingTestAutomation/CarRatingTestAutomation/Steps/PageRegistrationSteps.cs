﻿using CarRatingTestAutomation.Pages;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;

namespace CarRatingTestAutomation.Steps
{
    [Binding]
    public sealed class PageRegistrationSteps : Hooks
    {

        HomePage homePage;
        RegistrationPage registrationPage;    

        public void LaunchBuggy()
        {
            //driver.Navigate().GoToUrl("https://www.buggy.justtestit.org/");
            homePage = new HomePage(driver);
        }

        public void ViewUserRegistartionPage()
        {
            LaunchBuggy();
            homePage.ClickOnRegister();
            registrationPage = new RegistrationPage(driver);
        }


        [Given(@"a user views the registration page")]
        public void GivenAUserViewsTheRegistrationPage()
        {
            ViewUserRegistartionPage();
        }

        [When(@"the user registers with (.*) (.*) (.*) (.*) (.*)")]
        public void WhenTheUserRegistersWithData(string login, string firstname, string lastname, string password, string confirmPassword)
        {
            registrationPage.Register(login, firstname, lastname, password, confirmPassword);
        }

        [Then(@"(.*) should be displayed")]
        public void ThenSuccssShouldBeDisplayed(string message)
        {
            registrationPage.validateMessage(message);
        }



        [Given(@"a user logins with (.*) (.*)")]
        public void GivenAUserLoginsWith(string login, string password)
        {

            LaunchBuggy();
            homePage.Login(login, password);
        }

        [Then(@"the profile name should be displayed as (.*)")]
        public void ThenTheProfileNameShouldBeDisplayedAs(string firstname)
        {
            homePage.validateProfileName(firstname);
        }



    }
}
