﻿using CarRatingTestAutomation.Pages;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;

namespace CarRatingTestAutomation.Steps
{
    [Binding]
    public sealed class PageRegistrationSteps
    {
        IWebDriver driver;
        HomePage homePage;
        RegistrationPage registrationPage;

        public PageRegistrationSteps(IWebDriver webDriver)
        {
            driver = webDriver;
        }

        public void LaunchBuggy()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://www.buggy.justtestit.org/");
            Thread.Sleep(1000);
            homePage = new HomePage(driver);
        }

        public void ViewUserRegistartionPage()
        {
            LaunchBuggy();
            homePage.ClickOnRegister();
            registrationPage = new RegistrationPage(driver);
        }

        [Given(@"a user logins with (.*) (.*)")]
        public void GivenAUserLoginsWith(string login, string password)
        {

            LaunchBuggy();
            homePage.Login(login, password);
        }

        [Then(@"the profile name should be displayed as (.*)")]
        public void ThenTheProfileNameShouldBeDisplayedAs(string firstname)
        {
            homePage.validateProfileName(firstname);
        }


    }
}
